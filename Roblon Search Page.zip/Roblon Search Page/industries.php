<!--Get the samples from https://www.adobe.com/go/pdfembedapi_samples-->
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<style>
		.column {
			  float: left;
			  width: 50%;
			  padding: 10px;
			  height: 300px; 
			  padding-left: 50px;
		}
		.row:after {
			  content: "";
			  display: table;
			  clear: both;
		}
		.fntrw{
			color: #eeebdd;
			font-size: 3.1rem;
		}
		.container{
			position: relative;
		}
		.hd{
			text-align: center; 
			color: #eeebdd;
			font-size: 3.6rem;
		}
		.btn-lg{
			width: 150px;
		}
	</style>
</head>
<body style="background-color:black;">
	<h1 class = "hd"><font face="Verdana">Industries</font></h1>
	<p style="text-indent: 50px;"><font color="white">(To Know more click on the image or text)</font></p>
	<p></p>
	<div class="row fntrw container">
		<div class="column">
		    <a href="https://www.firefold.com/blogs/news/what-is-fiber-optic-cable"><img src="./images/foc.jpg" width="400" height="200" ></a>
		</div>
		<div class="column">
		    <a href="https://www.firefold.com/blogs/news/what-is-fiber-optic-cable">Fiber optic cables</a>
		</div>
		<div class="column" >
		    <a href="https://www.wirecable.in/"><img src="./images/wac.jpg" width="400" height="200"></a>
		</div>
		<div class="column" >
		    <a href = "https://www.wirecable.in/">Wire and Cables</a>
		</div>
		<div class="column">
		    <a href="https://www.eia.gov/energyexplained/oil-and-petroleum-products/offshore-oil-and-gas.php"><img src="./images/oog.jpg" width="400" height="200"></a>
		</div>
		<div class="column">
		    <a href="https://www.eia.gov/energyexplained/oil-and-petroleum-products/offshore-oil-and-gas.php">Offshore oil and gas</a>
		</div>
		<div class="column">
		    <a href="https://energyeducation.ca/encyclopedia/Power_plant#:~:text=A%20power%20plant%20is%20an,grid%20for%20society's%20electrical%20needs."><img src="./images/enr.jpg" width="400" height="200"></a>
		</div>
		<div class="column">
		    <a href="https://energyeducation.ca/encyclopedia/Power_plant#:~:text=A%20power%20plant%20is%20an,grid%20for%20society's%20electrical%20needs.">Energy</a>
		</div>
		<div class="column">
		    <a href="https://corporatefinanceinstitute.com/resources/knowledge/economics/industry/"><img src="./images/oi.jpg" width="400" height="200"></a>
		</div>
		<div class="column">
		    <a href="https://corporatefinanceinstitute.com/resources/knowledge/economics/industry/">Other Industries</a>
		</div>
	</div>
	<div class="container">
		<div class="row">
			<div class="column">
				<a href="./industries.php" type="button" class="btn btn-outline-warning btn-lg">Go To Top<span>&#8593;</span></a>
			</div>
			<div class="column">
				<a href="./index.php" type="button" class="btn btn-outline-warning btn-lg">Back</a>
			</div>
		</div>
	</div>
	<div class="container">
		<p></p>
	</div>
</body>
</html>