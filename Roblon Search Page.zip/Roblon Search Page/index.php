<!--Get the samples from https://www.adobe.com/go/pdfembedapi_samples-->
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<style>
		.fntrw{
			color: #eeebdd;
		}
		.fnt{
			color: #f8ede3;
			font-size: 20px;
			margin-right: 25px;
		}
		.search-form {
		    margin: 4em auto;
		    margin-top: 12em;
		    margin-right: auto;
		    margin-bottom: 4em;
		    margin-left: auto;
		    text-align: center;
		}
		.log{
			padding: center;
			margin-right: 100px;
		}
		.inpt{
        	border: none;
        	border-bottom: 2px solid red;
		}
		.site-footer {
		    background: #1d1d1b url(./images/backgrd.jpg) no-repeat 50% 0;
		    background-size: cover;
		    color: #fff;
		    font-size: 1.7rem;
		    line-height: 1.5em;
		    padding-bottom: 172px;
		    padding-top: 872px;
		}
		.site-footer .block {
		    margin-bottom: auto;
		}
		.top-left {
		  position: absolute;
		  top: 32px;
		  left: 56px;
		}
		.container{
			position: relative;
		}
		.heading {
		    font-size: 0.8rem;
		    color: black;
		    letter-spacing: .88px;
		    line-height: 1em;
		    max-width: 40%;
		}
		.subhead{
			font-size: 3.6rem;
    		line-height: 1.064em;
    		color: black;
    		max-width: 70%;
		}
		.column {
			  float: left;
			  width: 25%;
			  padding: 10px;
			  height: 300px; 
			  padding-left: 50px;
		}
		.row:after {
			  content: "";
			  display: table;
			  clear: both;
		}
		#footer{
			bottom: 0;
			margin-top: 1000px;
		}
	</style>
	<title>Roblon Search Page</title>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-light bg-dark">
  	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  	</button>
	<div class="collapse navbar-collapse" id="navbarNav">
	<ul class="navbar-nav">
	  <li class="nav-item active">
	    <a class="nav-link" href="./industries.php"><p class="fnt">Industries::</p> <span class="sr-only">(current)</span></a>
	  </li>
	  <li class="nav-item">
	    <a class="nav-link" href="#"><p class="fnt">Investor</p></a>
	  </li>
	</ul>
	</div>
	<a class="navbar-brand log" href="index.php">
    <img src="./images/logo.png" width="150" height="80" alt="">
	</a>
	<div class="collapse navbar-collapse" id="navbarNav">
	<ul class="navbar-nav">
	  <li class="nav-item">
	    <a class="nav-link" href="#"><p class="fnt">About</p><p></p></a>
	  </li>
	  <li class="nav-item">
	    <a class="nav-link disabled" href="#"><p class="fnt">Contact</p><p></p></a>
	  </li>
	  <li class="nav-item">
	    <a class="nav-link disabled" href="#"><p class="fnt">Downloads</p><p></p></a>
	  </li>
	  <li class="nav-item">
	    <a class="nav-link disabled" href="#"><p class="fnt">Search</p><p></p></a>
	  </li>
	</ul>
	</div>
	</nav>

	<div class="search-form">
		<form type = "Search" method="get">
			<input type = "Search" placeholder="SearchInputHolder" class="inpt">
			<button type="button" class="btn btn-warning"><b>SearchButton</b></button>
		</form>
	</div>

	<footer class="site-footer">
		<div class=" container">
			<img src="./images/yellow.png" width=100% height="320">
			<div class="top-left">
				<p align="left" class="heading"><b>Contact Us</b></p>
				<p align="left" class="subhead"><b>Are you looking for an industry specific solution? Get in touch.</b></p>
				<p><a href="contact.php"><span><blink>&#8594;</blink></span></a></p>
			</div>
		</div>
		<p></p>
		<div class="row" style="background-color:rgba(29,29,27,0.35);" id="footer">
		  <div class="column fntrw">
		    <img src="./images/logo.png">
		  </div>
		  <div class="column fntrw">
		  	<h2>Roblon A/S</h2>
		    <p>Nordhavnsvej 1<br>9900 Frederikshavn, DK</p>
		    <p>P:  + 45 9620 3300 <br><font style="color: yellow">E:  info[at]roblon.com</font></p>
		  </div>
		  <div class="column fntrw">
		  	<h2>Roblon US Inc</h2>
		    <p>3908 Hickory Boulevard<br>Granite Falls, NC 28630, USA</p>
		    <p>P:  +1  828 396 2121<br><font style="color: yellow">E: info[at]roblon.com</font></p>
		  </div>
		  <div class="column">
		    <p><font style="color: yellow">Cookie policy</font></p>
		  </div>
		</div>
	</footer>

</body>
</html>